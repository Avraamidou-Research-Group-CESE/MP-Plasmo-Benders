using PlasmoSchwarz
using Test

@testset "PlasmoSchwarz.jl" begin
    include("test_optimizer.jl")
end
